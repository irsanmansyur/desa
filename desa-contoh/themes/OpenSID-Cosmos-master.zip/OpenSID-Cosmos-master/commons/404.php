<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div id="notfound">
	<div class="notfound">
		<div class="notfound-404">
			<div class="h1">4<span></span>4</div>
		</div>
		<div class="h2">UPS! HALAMAN TIDAK DITEMUKAN</div>
		<p>Anda telah terdampar di halaman yang datanya tidak ada lagi di web ini. Mohon periksa kembali, atau laporkan kepada kami.</p>
		<a href="<?= site_url('first') ?>">Kembali ke halaman utama</a>
	</div>
</div>